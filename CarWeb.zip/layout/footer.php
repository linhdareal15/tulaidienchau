<div class="footer-clean">
        <footer>
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-sm-4 col-md-3 item pt-5">
                        <h3>ĐỊA CHỈ</h3>
                        <ul>
                            <li><a href="#">Quốc lộ 7A gần khu đô thị Hoàng Sơn - Thị Trấn Diễn Châu - Tỉnh Nghệ An</a></li>
                            <li><a href="#"></a></li>
                            <li><a href="#"></a></li>
                        </ul>
                    </div>
                    <div class="col-sm-4 col-md-3 item pt-5">
                        <h3>About</h3>
                        <ul>
                            <li><a href="#">Email: hienbia333@gmail.com</a></li>
                            <li><a href="#">Số điện thoại: 0979 253 486</a></li>
                            <li><a href="#">0971 557 017</a></li>
                        </ul>
                    </div>
                    <!-- <div class="col-sm-4 col-md-3 item">
                        <h3>Careers</h3>
                        <ul>
                            <li><a href="#">Job openings</a></li>
                            <li><a href="#">Employee success</a></li>
                            <li><a href="#">Benefits</a></li>
                        </ul>
                    </div> -->
                    <div class="col-lg-3 col-md-6 item social justify-content-center pt-5">
                        <div class=" row item social justify-content-center">
                        <a href="https://www.facebook.com/Ch%E1%BB%A3-oto-c%C5%A9-xe-l%C6%B0%E1%BB%9Bt-DC-YT-Ngh%E1%BB%87-An-106326278559168/"><i class="icon ion-social-facebook"></i></a>
                        <a href="#"><i class="icon ion-social-instagram"></i></a>
                        
                        </div>
                        
                        <p class="copyright">Bản Quyền © LinhPhong 2021</p>
                    </div>
                    <div class="col-lg-3 col-md-6 ">
                        <center><img src="img/ZaloQr.jpg" style="width: 200px; height: 200px;" alt=""></center>
                    </div>
                </div>
            </div>
        </footer>
    </div>