
  <section class="services" id='second'>
        <!--services-box---------->
        <div class="services-box">
            <i class="fas fa-shipping-fast"></i>
            <span>MIỄN PHÍ VẬN CHUYỂN</span>
            <p> Dưới 5km</p>
        </div>
        <!--services-box---------->
        <div class="services-box">
            <i class="fas fa-headphones-alt"></i>
            <span>HỖ TRỢ 24/7</span>
            <p>Chúng tôi hỗ trợ 24/7</p>
        </div>
        <!--services-box---------->
        <div class="services-box">
            <i class="fas fa-sync"></i>
            <span>KÝ GỬI OTO CŨ-MỚI</span>
            <p>Uy tín tạo niềm tin</p>
        </div>
        
    </section>