
  <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>
   
    
    <header class="site-navbar js-sticky-header site-navbar-target" role="banner">

      <div class="container">
        <div class="row align-items-center">
          
          <div class="col-6 col-xl-2">
            <h1 class="mb-0 site-logo"><a href="index.php">TULAIDIENCHAU<span class="text-primary"></span> </a></h1>
          </div>

          <div class="col-12 col-md-10 d-none d-xl-block">
            <nav class="site-navigation position-relative text-right" role="navigation">

              <ul class="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block">
                <li><a href="index.php" class="nav-link">TRANG CHỦ</a></li>
                <li><a href="hireCAR.php" class="nav-link">THUÊ XE</a></li>
                <li class="has-children">
                  <a href="#about-section" class="nav-link">MUA BÁN XE</a>
                  <ul class="dropdown">
                    <li><a href="filterCategory.php?sub_category_id=2" class="nav-link">XE 5-7 CHỖ</a></li>
                    <li><a href="filterCategory.php?sub_category_id=1" class="nav-link">XE BÁN TẢI</a></li>
                    <li><a href="filterCategory.php?sub_category_id=3" class="nav-link">XE TẢI CHỞ HÀNG</a></li>
                    <!-- <li class="has-children">
                      <a href="#">KHÁC</a>
                      <ul class="dropdown">
                        <li><a href="#">Menu One</a></li>
                        <li><a href="#">Menu Two</a></li>
                        <li><a href="#">Menu Three</a></li>
                      </ul>
                    </li> -->
                  </ul>
                </li>
                <!-- <li><a href="#blog-section" class="nav-link">Blog</a></li> -->
                <li><a href="carintro.php" class="nav-link">VỀ CHÚNG TÔI</a></li>
                <li class="social"><a href="https://www.facebook.com/Ch%E1%BB%A3-oto-c%C5%A9-xe-l%C6%B0%E1%BB%9Bt-DC-YT-Ngh%E1%BB%87-An-106326278559168" class="nav-link"><span class="icon-facebook"></span></a></li>
                <!-- <li class="social"><a href="#contact-section" class="nav-link"><span class="icon-twitter"></span></a></li>
                <li class="social"><a href="#contact-section" class="nav-link"><span class="icon-linkedin"></span></a></li> -->
              </ul>
            </nav>
          </div>


          <div class="col-6 d-inline-block d-xl-none ml-md-0 py-3" style="position: relative; top: 3px;"><a href="#" class="site-menu-toggle js-menu-toggle float-right"><span class="icon-menu h3"></span></a></div>

        </div>
      </div>
      
    </header>
    <div class="hero"></div>
